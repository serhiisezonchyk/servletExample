create view lastmonthlack(customer_id, name, phone, legality) as
SELECT "Customer".customer_id,
       "Customer".name,
       "Customer".phone,
       "Customer".legality
FROM "Customer"
         JOIN "Order" USING (customer_id)
         JOIN "Car" ON "Order".car_id = "Car".car_id
WHERE "Order".date_ord > (CURRENT_DATE - 30)
  AND "Order".date_ord < CURRENT_DATE
  AND "Car".quantity < "Order".quantity;

alter table lastmonthlack
    owner to postgres;

grant select on lastmonthlack to secretary;

