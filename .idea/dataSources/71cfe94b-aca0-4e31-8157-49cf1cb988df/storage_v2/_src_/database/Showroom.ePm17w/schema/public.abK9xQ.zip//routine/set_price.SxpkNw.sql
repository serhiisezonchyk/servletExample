create function set_price() returns trigger
    language plpgsql
as
$$
BEGIN
	UPDATE "Order" ord
	SET price = quantity * (
	SELECT price FROM "Car" car
	WHERE car.car_id = ord.car_id);
	RETURN NEW;
END;
$$;

alter function set_price() owner to postgres;

