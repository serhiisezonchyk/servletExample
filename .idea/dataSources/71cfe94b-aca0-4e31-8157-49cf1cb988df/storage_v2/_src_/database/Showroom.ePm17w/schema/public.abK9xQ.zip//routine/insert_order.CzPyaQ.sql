create function insert_order(customer_id integer, car_id integer, seller_id integer, quantity integer) returns void
    language plpgsql
as
$$
BEGIN
	IF customer_id NOT IN (SELECT "Customer".customer_id FROM "Customer")
		THEN RAISE EXCEPTION 'invalid customer_id=%',customer_id
		USING HINT = 'THIS id NOT EXIST';
		END IF;
	IF car_id NOT IN (SELECT "Car".car_id FROM "Car")
		THEN RAISE EXCEPTION 'invalid car_id=%',car_id
		USING HINT = 'THIS id NOT EXIST';
		END IF;
	IF seller_id NOT IN (SELECT "Seller".seller_id FROM "Seller")
		THEN RAISE EXCEPTION 'invalid seller_id=%',seller_id
		USING HINT = 'THIS id NOT EXIST';
		END IF;
	IF quantity < 1
		THEN RAISE EXCEPTION 'zero_quantity'
		USING HINT = 'quantity can`t be less zero';
		END IF;
		
   INSERT INTO "Order"(customer_id, car_id, seller_id, date_ord, quantity) 
	VALUES($1, $2, $3, CURRENT_DATE, $4);
	EXCEPTION
	 WHEN not_null_violation  THEN RAISE EXCEPTION 'You can`t enter "null" to car_id';

END;
$$;

alter function insert_order(integer, integer, integer, integer) owner to postgres;

