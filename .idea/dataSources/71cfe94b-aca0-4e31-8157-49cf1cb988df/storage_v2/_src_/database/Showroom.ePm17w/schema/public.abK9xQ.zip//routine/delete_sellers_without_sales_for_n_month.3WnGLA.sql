create function delete_sellers_without_sales_for_n_month(month_count integer) returns integer
    language plpgsql
as
$$
DECLARE
	counter integer = 0;
BEGIN
EXECUTE '
	SELECT COUNT(*) FROM "Seller" WHERE seller_id  NOT IN(
	SELECT seller_id FROM "Order" 
	WHERE date_ord BETWEEN CURRENT_DATE-(INTERVAL '''||month_count||' month'') AND CURRENT_DATE)'
	INTO counter;
	IF counter = 0 THEN RETURN 0;
	END IF;
	
EXECUTE '
	DELETE FROM "Seller" WHERE seller_id  NOT IN(
	SELECT seller_id FROM "Order" 
	WHERE date_ord BETWEEN CURRENT_DATE-(INTERVAL '''||month_count||' month'') AND CURRENT_DATE)';
 	RAISE NOTICE 'Was deleted % rows', counter;
 	RETURN counter;
END;
$$;

alter function delete_sellers_without_sales_for_n_month(integer) owner to postgres;

