create function delete_orders() returns trigger
    language plpgsql
as
$$
BEGIN
	INSERT INTO archive_orders VALUES (OLD.order_id, OLD.customer_id, OLD.car_id,
						OLD.seller_id, OLD.date_ord, OLD.quantity, OLD.price, 
						OLD.payment, OLD.availability, OLD.confirmed);
	RETURN OLD;
END;
$$;

alter function delete_orders() owner to postgres;

