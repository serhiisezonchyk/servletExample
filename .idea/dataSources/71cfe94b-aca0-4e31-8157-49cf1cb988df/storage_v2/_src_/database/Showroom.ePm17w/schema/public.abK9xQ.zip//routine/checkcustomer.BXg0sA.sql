create function checkcustomer() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.name, NEW.phone, NEW.legality) IN
		(SELECT "name", phone, legality FROM "Customer") THEN
		RAISE EXCEPTION 'This customer is already exist';
	END IF;
	RETURN NEW;
END;
$$;

alter function checkcustomer() owner to postgres;

