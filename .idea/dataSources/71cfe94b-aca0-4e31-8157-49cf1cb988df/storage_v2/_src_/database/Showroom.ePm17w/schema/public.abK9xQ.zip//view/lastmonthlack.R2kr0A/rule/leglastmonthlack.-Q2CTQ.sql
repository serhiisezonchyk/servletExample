CREATE RULE leglastmonthlack AS
    ON UPDATE TO lastmonthlack DO INSTEAD  UPDATE "Customer" SET customer_id = new.customer_id, name = new.name, phone = new.phone, legality = new.legality
  WHERE "Customer".customer_id = old.customer_id;

