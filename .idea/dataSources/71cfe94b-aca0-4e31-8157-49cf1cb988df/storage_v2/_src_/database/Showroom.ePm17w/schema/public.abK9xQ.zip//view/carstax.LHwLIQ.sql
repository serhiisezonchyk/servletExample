create view carstax (car_id, name, model, year, engine, price, quantity, complectation, "priceWithTax") as
SELECT "Car".car_id,
       "Car".name,
       "Car".model,
       "Car".year,
       "Car".engine,
       "Car".price,
       "Car".quantity,
       "Car".complectation,
       "Car".price * 1.2::double precision AS "priceWithTax"
FROM "Car"
WHERE "Car".price > 10000::money;

alter table carstax
    owner to postgres;

grant select on carstax to carmanager;

