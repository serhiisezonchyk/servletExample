create function del_customers_with_no_orders(OUT customer_id integer, OUT name character varying, OUT phone character varying, OUT legality boolean, date, date) returns SETOF record
    language sql
as
$$
DELETE FROM "Customer" WHERE customer_id IN (
	SELECT customer_id FROM "Order" WHERE "Order".date_ord BETWEEN $1 AND $2 )
	RETURNING *;

$$;

alter function del_customers_with_no_orders(out integer, out varchar, out varchar, out boolean, date, date) owner to postgres;

