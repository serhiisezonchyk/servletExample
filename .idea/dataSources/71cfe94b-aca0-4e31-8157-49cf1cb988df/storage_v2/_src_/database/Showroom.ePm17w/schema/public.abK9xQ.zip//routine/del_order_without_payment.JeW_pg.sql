create function del_order_without_payment(OUT order_id integer, OUT customer_id integer, OUT car_id integer, OUT seller_id integer, OUT date_ord date, OUT quantity integer, OUT price money, OUT payment character varying, OUT availability boolean, OUT confirmed boolean, date, date) returns SETOF record
    language sql
as
$$
DELETE FROM "Order" WHERE date_ord BETWEEN $1 AND $2
	AND  payment = 'no'
	RETURNING *;

$$;

alter function del_order_without_payment(out integer, out integer, out integer, out integer, out date, out integer, out money, out varchar, out boolean, out boolean, date, date) owner to postgres;

