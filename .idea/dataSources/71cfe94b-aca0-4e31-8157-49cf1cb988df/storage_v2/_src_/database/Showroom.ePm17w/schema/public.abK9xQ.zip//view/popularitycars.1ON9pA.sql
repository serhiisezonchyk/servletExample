create view popularitycars (name, model, year, engine, complectation, total_price, sum, "Popularity") as
WITH auto_avgprice AS (
    SELECT car.car_id,
           car.name,
           car.model,
           car.year,
           car.engine,
           car.complectation,
           sum(ord.quantity * car.price) AS total_price,
           sum(ord.quantity)             AS sum
    FROM "Car" car,
         "Order" ord
    WHERE car.car_id = ord.car_id
    GROUP BY car.car_id
)
SELECT auto_avgprice.name,
       auto_avgprice.model,
       auto_avgprice.year,
       auto_avgprice.engine,
       auto_avgprice.complectation,
       auto_avgprice.total_price,
       auto_avgprice.sum,
       'Супер Популярный'::text AS "Popularity"
FROM auto_avgprice
WHERE auto_avgprice.total_price > (0.1::double precision * ((SELECT sum(auto_avgprice_1.total_price) AS sum
                                                             FROM auto_avgprice auto_avgprice_1)))
  AND auto_avgprice.sum::numeric > (0.3 * ((SELECT sum(auto_avgprice_1.sum) AS sum
                                            FROM auto_avgprice auto_avgprice_1)))
UNION
SELECT auto_avgprice.name,
       auto_avgprice.model,
       auto_avgprice.year,
       auto_avgprice.engine,
       auto_avgprice.complectation,
       auto_avgprice.total_price,
       auto_avgprice.sum,
       'Популярный'::text AS "Popularity"
FROM auto_avgprice
WHERE auto_avgprice.total_price < (0.1::double precision * ((SELECT sum(auto_avgprice_1.total_price) AS sum
                                                             FROM auto_avgprice auto_avgprice_1)))
  AND auto_avgprice.total_price > (0.05::double precision * ((SELECT sum(auto_avgprice_1.total_price) AS sum
                                                              FROM auto_avgprice auto_avgprice_1)))
  AND auto_avgprice.sum::numeric < (0.3 * ((SELECT sum(auto_avgprice_1.sum) AS sum
                                            FROM auto_avgprice auto_avgprice_1)))
  AND auto_avgprice.sum::numeric > (0.1 * ((SELECT sum(auto_avgprice_1.sum) AS sum
                                            FROM auto_avgprice auto_avgprice_1)))
UNION
SELECT auto_avgprice.name,
       auto_avgprice.model,
       auto_avgprice.year,
       auto_avgprice.engine,
       auto_avgprice.complectation,
       auto_avgprice.total_price,
       auto_avgprice.sum,
       'Обычный'::text AS "Popularity"
FROM auto_avgprice
WHERE auto_avgprice.total_price < (0.05::double precision * ((SELECT sum(auto_avgprice_1.total_price) AS sum
                                                              FROM auto_avgprice auto_avgprice_1)))
   OR auto_avgprice.sum::numeric < (0.1 * ((SELECT sum(auto_avgprice_1.sum) AS sum
                                            FROM auto_avgprice auto_avgprice_1)))
ORDER BY 8 DESC;

alter table popularitycars
    owner to postgres;

grant select on popularitycars to economist;

